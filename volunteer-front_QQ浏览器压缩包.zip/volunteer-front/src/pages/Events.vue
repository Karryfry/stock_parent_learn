<template>
  <div>
    <h1>活动管理</h1>
    <!-- 加载状态提示 -->
    <div v-if="loading">加载中...</div>
    <!-- 错误提示 -->
    <div v-if="error" class="error-message">{{ error }}</div>
    <button @click="showAddModal = true">新增活动</button>
    <table>
      <thead>
        <tr>
          <th>活动名称</th>
          <th>开始时间</th>
          <th>结束时间</th>
          <th>地点</th>
          <th>描述</th>
          <th>组织者</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="event in events" :key="event.id">
          <td>{{ event.title }}</td>
          <td>{{ formatDateTime(event.start_time) }}</td>
          <td>{{ formatDateTime(event.end_time) }}</td>
          <td>{{ event.location }}</td>
          <td>{{ event.description }}</td>
          <td>{{ event.organizer }}</td>
          <td>
            <button @click="editEvent(event)">编辑</button>
            <button @click="deleteEvent(event.id)">删除</button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- 新增活动模态框 -->
    <div v-if="showAddModal" class="modal">
      <div class="modal-content">
        <span class="close" @click="showAddModal = false">&times;</span>
        <h2>新增活动</h2>
        <form @submit.prevent="addEvent">
          <label for="title">活动名称:</label>
          <input type="text" id="title" v-model="newActivity.title" required style="width: 100%; box-sizing: border-box; margin-bottom: 10px; padding: 8px;">
          <label for="start_time">开始时间:</label>
          <input type="datetime-local" id="start_time" v-model="newActivity.start_time" required style="width: 100%; box-sizing: border-box; margin-bottom: 10px; padding: 8px;">
          <label for="end_time">结束时间:</label>
          <input type="datetime-local" id="end_time" v-model="newActivity.end_time" required style="width: 100%; box-sizing: border-box; margin-bottom: 10px; padding: 8px;">
          <label for="location">地点:</label>
          <input type="text" id="location" v-model="newActivity.location" required style="width: 100%; box-sizing: border-box; margin-bottom: 10px; padding: 8px;">
          <label for="description">描述:</label>
          <textarea id="description" v-model="newActivity.description" style="width: 100%; box-sizing: border-box; margin-bottom: 10px; padding: 8px;"></textarea>
          <label for="organizer">组织者:</label>
          <input type="text" id="organizer" v-model="newActivity.organizer" required style="width: 100%; box-sizing: border-box; margin-bottom: 10px; padding: 8px;">
          <button type="submit">保存</button>
          <button @click="showAddModal = false">取消</button>
        </form>
      </div>
    </div>

    <!-- 编辑活动模态框 -->
    <div v-if="showEditModal" class="modal">
      <div class="modal-content">
        <span class="close" @click="showEditModal = false">&times;</span>
        <h2>编辑活动</h2>
        <form @submit.prevent="updateEvent">
          <label for="edit_title">活动名称:</label>
          <input type="text" id="edit_title" v-model="editedActivity.title" required style="width: 100%; box-sizing: border-box; margin-bottom: 10px; padding: 8px;">
          <label for="edit_start_time">开始时间:</label>
          <input type="datetime-local" id="edit_start_time" v-model="editedActivity.start_time" required style="width: 100%; box-sizing: border-box; margin-bottom: 10px; padding: 8px;">
          <label for="edit_end_time">结束时间:</label>
          <input type="datetime-local" id="edit_end_time" v-model="editedActivity.end_time" required style="width: 100%; box-sizing: border-box; margin-bottom: 10px; padding: 8px;">
          <label for="edit_location">地点:</label>
          <input type="text" id="edit_location" v-model="editedActivity.location" required style="width: 100%; box-sizing: border-box; margin-bottom: 10px; padding: 8px;">
          <label for="edit_description">描述:</label>
          <textarea id="edit_description" v-model="editedActivity.description" style="width: 100%; box-sizing: border-box; margin-bottom: 10px; padding: 8px;"></textarea>
          <label for="edit_organizer">组织者:</label>
          <input type="text" id="edit_organizer" v-model="editedActivity.organizer" required style="width: 100%; box-sizing: border-box; margin-bottom: 10px; padding: 8px;">
          <button type="submit">保存</button>
          <button @click="showEditModal = false">取消</button>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
import api from '../services/api';
import { toast } from 'vue3-toastify';
import 'vue3-toastify/dist/index.css';

export default {
  data() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const currentDateTime = `${year}-${month}-${day}T${hours}:${minutes}`;

    return {
      events: [],
      newActivity: {
        title: '',
        start_time: currentDateTime,
        end_time: '',
        location: '',
        description: '',
        organizer: ''
      },
      editedActivity: null,
      showAddModal: false,
      showEditModal: false,
      loading: false,
      error: null
    };
  },
  async created() {
    this.loading = true;
    try {
      const response = await api.getEvents();
      if (Array.isArray(response)) {
        this.events = response;
      } else {
        throw new Error('获取的活动数据格式不正确');
      }
    } catch (err) {
      this.error = '获取活动列表失败，请稍后重试。';
      toast.error(this.error);
    } finally {
      this.loading = false;
    }
  },
  methods: {
    formatDateTime(dateTimeStr) {
      if (!dateTimeStr) return '';
      const date = new Date(dateTimeStr);
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      return `${year}-${month}-${day} ${hours}:${minutes}`;
    },
    // 将日期转换为 datetime-local 格式
    convertToDateTimeLocalFormat(dateTimeStr) {
      if (!dateTimeStr) return '';
      const date = new Date(dateTimeStr);
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      return `${year}-${month}-${day}T${hours}:${minutes}`;
    },
    async addEvent() {
      // 数据验证
      if (!this.newActivity.title || !this.newActivity.start_time || !this.newActivity.end_time || !this.newActivity.location || !this.newActivity.organizer) {
        this.error = '活动名称、开始时间、结束时间、地点和组织者为必填项';
        toast.error(this.error);
        return;
      }
      if (new Date(this.newActivity.end_time) <= new Date(this.newActivity.start_time)) {
        this.error = '结束时间必须晚于开始时间';
        toast.error(this.error);
        return;
      }

      this.loading = true;
      try {
        const response = await api.createEvent(this.newActivity);
        if (typeof response === 'object' && response!== null) {
          this.events.push(response);
          this.showAddModal = false;
          const now = new Date();
          const year = now.getFullYear();
          const month = String(now.getMonth() + 1).padStart(2, '0');
          const day = String(now.getDate()).padStart(2, '0');
          const hours = String(now.getHours()).padStart(2, '0');
          const minutes = String(now.getMinutes()).padStart(2, '0');
          const currentDateTime = `${year}-${month}-${day}T${hours}:${minutes}`;
          this.newActivity = {
            title: '',
            start_time: currentDateTime,
            end_time: '',
            location: '',
            description: '',
            organizer: ''
          };
          toast.success('新增活动成功');
        } else {
          throw new Error('新增活动返回的数据格式不正确');
        }
      } catch (err) {
        this.error = `新增活动失败: ${err.message}`;
        toast.error(this.error);
      } finally {
        this.loading = false;
      }
    },
    editEvent(event) {
      this.editedActivity = {
        ...event,
        start_time: this.convertToDateTimeLocalFormat(event.start_time),
        end_time: this.convertToDateTimeLocalFormat(event.end_time)
      };
      this.showEditModal = true;
    },
    async updateEvent() {
      // 数据验证
      if (!this.editedActivity.title || !this.editedActivity.start_time || !this.editedActivity.end_time || !this.editedActivity.location || !this.editedActivity.organizer) {
        this.error = '活动名称、开始时间、结束时间、地点和组织者为必填项';
        toast.error(this.error);
        return;
      }
      if (new Date(this.editedActivity.end_time) <= new Date(this.editedActivity.start_time)) {
        this.error = '结束时间必须晚于开始时间';
        toast.error(this.error);
        return;
      }

      this.loading = true;
      try {
        const response = await api.updateEvent(this.editedActivity.id, this.editedActivity);
        if (typeof response === 'object' && response!== null) {
          const index = this.events.findIndex(e => e.id === response.id);
          if (index!== -1) {
            this.events[index] = response;
          }
          this.showEditModal = false;
          toast.success('编辑活动成功');
        } else {
          throw new Error('编辑活动返回的数据格式不正确');
        }
      } catch (err) {
        this.error = `编辑活动失败: ${err.message}`;
        toast.error(this.error);
      } finally {
        this.loading = false;
      }
    },
    async deleteEvent(id) {
      this.loading = true;
      try {
        const response = await api.deleteEvent(id);
        if (response.message === '活动删除成功') {
          this.events = this.events.filter(e => e.id!== id);
          this.error = null;
          toast.success('删除活动成功');
        } else {
          this.error = '删除活动失败，请稍后重试。';
          toast.error(this.error);
        }
      } catch (err) {
        this.error = `删除活动失败: ${err.message}`;
        toast.error(this.error);
      } finally {
        this.loading = false;
      }
    }
  }
};
</script>

<style scoped>
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}

th,
td {
  border: 1px solid #ddd;
  padding: 12px;
  text-align: left;
}

th {
  background-color: #f2f2f2;
}

button {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 8px 16px;
  cursor: pointer;
  margin-right: 5px;
  border-radius: 4px;
}

button:hover {
  background-color: #0056b3;
}

.modal {
  display: block;
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.4);
}

.modal-content {
  background-color: #fefefe;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #888;
  width: 300px;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  min-height: 200px;
  position: relative;
  top: 50%;
  transform: translateY(-50%);
}

.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}

.error-message {
  color: red;
  margin-top: 10px;
}
</style>