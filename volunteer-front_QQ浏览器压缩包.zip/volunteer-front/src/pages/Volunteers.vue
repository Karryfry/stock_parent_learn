<template>
  <div>
    <h1>志愿者管理</h1>
    
    <!-- 加载状态 -->
    <div v-if="loading">加载中...</div>
    <!-- 志愿者列表 -->
    <table v-else>
      <thead>
        <tr>
          <th>姓名</th>
          <th>学号</th>
          <th>联系方式</th>
          <th>性别</th>
          <th>年龄</th>
          <th>邮箱</th>
          <th>地址</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="volunteer in volunteers" :key="volunteer.id">
          <td>{{ volunteer.name }}</td>
          <td>{{ volunteer.student_id }}</td>
          <td>{{ volunteer.phone }}</td>
          <td>{{ volunteer.gender }}</td>
          <td>{{ volunteer.age }}</td>
          <td>{{ volunteer.email }}</td>
          <td>{{ volunteer.address }}</td>
          <td>
            <button @click="editVolunteer(volunteer.id)">编辑</button>
            <button @click="deleteVolunteer(volunteer.id)">删除</button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- 添加志愿者模态框 -->
    

    <!-- 编辑志愿者模态框 -->
    <div v-if="showEditModal" class="modal">
      <div class="modal-content">
        <span class="close" @click="showEditModal = false">&times;</span>
        <h2>编辑志愿者</h2>
        <form @submit.prevent="updateVolunteer(editVolunteerId)">
          <input v-model="editedVolunteer.name" placeholder="姓名" />
          <input v-model="editedVolunteer.student_id" placeholder="学号" />
          <input v-model="editedVolunteer.phone" placeholder="联系方式" />
          <select v-model="editedVolunteer.gender">
            <option value="男">男</option>
            <option value="女">女</option>
          </select>
          <input v-model="editedVolunteer.age" placeholder="年龄" type="number" />
          <input v-model="editedVolunteer.email" placeholder="邮箱" />
          <input v-model="editedVolunteer.address" placeholder="地址" />
          <button type="submit">提交</button>
        </form>
      </div>
    </div>

    <!-- 错误提示 -->
    <div v-if="error" class="error-message">{{ error }}</div>
  </div>
</template>

<script>
import api from '../services/api';

export default {
  data() {
    return {
      volunteers: [],
      newVolunteer: {
        name: '',
        student_id: '',
        phone: '',
        gender: '男',
        age: null,
        email: '',
        address: ''
      },
      editedVolunteer: {
        name: '',
        student_id: '',
        phone: '',
        gender: '男',
        age: null,
        email: '',
        address: ''
      },
      editVolunteerId: null,
      showAddModal: false,
      showEditModal: false,
      loading: false,
      error: null
    };
  },
  async created() {
    this.loading = true;
    try {
      this.volunteers = await api.getVolunteers();
    } catch (err) {
      this.error = '获取志愿者列表失败，请稍后重试。';
    } finally {
      this.loading = false;
    }
  },
  methods: {
    // async addVolunteer() {
    //   this.loading = true;
    //   try {
    //     const addedVolunteer = await api.addVolunteer(this.newVolunteer);
    //     this.volunteers.push(addedVolunteer);
    //     this.showAddModal = false;
    //     this.newVolunteer = {
    //       name: '',
    //       student_id: '',
    //       phone: '',
    //       gender: '男',
    //       age: null,
    //       email: '',
    //       address: ''
    //     };
    //   } catch (err) {
    //     this.error = '添加志愿者失败，请稍后重试。';
    //   } finally {
    //     this.loading = false;
    //   }
    // },
    async editVolunteer(id) {
      this.loading = true;
      try {
        const volunteer = this.volunteers.find(v => v.id === id);
        this.editedVolunteer = { ...volunteer };
        this.editVolunteerId = id;
        this.showEditModal = true;
      } catch (err) {
        this.error = '获取志愿者信息失败，请稍后重试。';
      } finally {
        this.loading = false;
      }
    },
    async updateVolunteer(id) {
      this.loading = true;
      try {
        await api.updateVolunteer(id, this.editedVolunteer);
        const index = this.volunteers.findIndex(v => v.id === id);
        if (index !== -1) {
          this.volunteers[index] = { ...this.editedVolunteer, id };
        }
        this.showEditModal = false;
      } catch (err) {
        this.error = '更新志愿者信息失败，请稍后重试。';
      } finally {
        this.loading = false;
      }
    },
    async deleteVolunteer(id) {
      this.loading = true;
      try {
        await api.deleteVolunteer(id);
        this.volunteers = this.volunteers.filter(v => v.id !== id);
      } catch (err) {
        this.error = '删除志愿者失败，请稍后重试。';
      } finally {
        this.loading = false;
      }
    }
  }
};
</script>

<style scoped>
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}

th,
td {
  border: 1px solid #ddd;
  padding: 12px;
  text-align: left;
}

th {
  background-color: #f2f2f2;
}

button {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 8px 16px;
  cursor: pointer;
  margin-right: 5px;
  border-radius: 4px;
}

button:hover {
  background-color: #0056b3;
}

.modal {
  display: block;
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.4);
}

.modal-content {
  background-color: #fefefe;
  margin: 15% auto;
  padding: 20px;
  border: 1px solid #888;
  width: 300px;
  border-radius: 4px;
}

.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}

.error-message {
  color: red;
  margin-top: 10px;
}
</style>