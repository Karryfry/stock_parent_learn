<template>
  <div class="login-container">
    <h1 class="login-title">
    </h1>
    <form @submit.prevent="handleLogin" class="login-form">
      <div class="form-group">
        <label for="username">
          <i class="fas fa-user"></i> 用户名：
        </label>
        <input id="username" type="text" v-model="username" />
      </div>
      <div class="form-group">
        <label for="password">
          <i class="fas fa-key"></i> 密码：
        </label>
        <input id="password" type="password" v-model="password" />
      </div>
      <button type="submit" class="login-button">
        <i class="fas fa-sign-in-alt"></i> 登录
      </button>
      <div v-if="error" class="error-message">
        <i class="fas fa-exclamation-circle"></i> {{ error }}
      </div>
    </form>
  </div>
</template>

<script>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '../stores/auth'; // 使用 Pinia 管理登录状态

export default {
  setup() {
    const username = ref('');
    const password = ref('');
    const error = ref('');
    const router = useRouter();
    const authStore = useAuthStore();

    const handleLogin = async () => {
      try {
        const user = await authStore.login(username.value, password.value);
        if (user.role === 'admin') {
          router.push('/dashboard');
        } else if (user.role === 'user') {
          router.push('/personal');
        } else {
          // 可以根据实际情况添加更多角色的跳转逻辑
          router.push('/dashboard');
        }
      } catch (err) {
        error.value = '登录失败，请检查用户名和密码';
      }
    };

    return {
      username,
      password,
      error,
      handleLogin,
    };
  },
};
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background-color: #f4f4f4;
  background-image: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); /* 添加渐变背景 */
}

.login-title {
  text-align: center;
  margin-bottom: 30px;
  font-size: 28px;
  color: #333;
  font-family: 'Arial', sans-serif; /* 设置字体 */
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1); /* 添加文字阴影 */
}

.login-form {
  background-color: white;
  padding: 25px 30px; /* 增加内边距 */
  border-radius: 8px; /* 增加圆角弧度 */
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15); /* 调整阴影效果 */
  width: 320px; /* 适当增加宽度 */
  transition: all 0.3s ease; /* 添加过渡效果 */
}

.login-form:hover {
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.2); /* 鼠标悬停时的阴影效果 */
}

.form-group {
  margin-bottom: 20px; /* 增加底部间距 */
}

.form-group label {
  display: flex;
  align-items: center;
  margin-bottom: 8px;
  font-weight: 500; /* 调整字体粗细 */
  color: #333;
  font-size: 16px; /* 调整字体大小 */
}

.form-group label i {
  margin-right: 12px;
}

.form-group input {
  padding: 12px; /* 增加内边距 */
  border: 1px solid #e0e0e0; /* 调整边框颜色 */
  border-radius: 6px; /* 增加圆角弧度 */
  width: 100%;
  font-size: 16px; /* 调整字体大小 */
  transition: border-color 0.3s ease; /* 添加过渡效果 */
}

.form-group input:focus {
  outline: none;
  border-color: #007bff; /* 聚焦时的边框颜色 */
  box-shadow: 0 0 5px rgba(0, 123, 255, 0.2); /* 聚焦时的阴影效果 */
}

.login-button {
  display: block;
  width: 100%;
  padding: 14px; /* 增加内边距 */
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 6px; /* 增加圆角弧度 */
  cursor: pointer;
  font-weight: 500; /* 调整字体粗细 */
  font-size: 16px; /* 调整字体大小 */
  transition: background-color 0.3s ease;
}

.login-button:hover {
  background-color: #0056b3;
}

.error-message {
  color: red;
  margin-top: 15px; /* 增加顶部间距 */
  text-align: center;
  font-size: 14px; /* 调整字体大小 */
}

.error-message i {
  margin-right: 8px;
}
</style>