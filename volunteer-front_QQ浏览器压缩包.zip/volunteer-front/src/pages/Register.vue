<template>
    <div class="register-container">
        <h1>用户注册</h1>
        <form @submit.prevent="handleRegister">
            <div class="form-group">
                <label for="username">用户名:</label>
                <input id="username" v-model="username" type="text" placeholder="请输入用户名" required />
            </div>
            <div class="form-group">
                <label for="password">密码:</label>
                <input id="password" v-model="password" type="password" placeholder="请输入密码" required />
            </div>
            <button type="submit">注册</button>
        </form>
        <div v-if="errorMessage" class="error-message">{{ errorMessage }}</div>
        <div v-if="successMessage" class="success-message">{{ successMessage }}</div>
    </div>
</template>

<script>
import axios from 'axios';
import { useRouter } from 'vue-router';

export default {
    data() {
        return {
            username: '',
            password: '',
            errorMessage: '',
            successMessage: ''
        };
    },
    setup() {
        const router = useRouter();
        return {
            router
        };
    },
    methods: {
        async handleRegister() {
            try {
                const response = await axios.post('http://localhost:3000/api/register', {
                    username: this.username,
                    password: this.password
                });
                this.successMessage = '注册成功，请登录后完善信息！';
                this.errorMessage = '';
                // 清空表单
                this.username = '';
                this.password = '';
                // 跳转到登录界面
                this.router.push('/login');
            } catch (error) {
                this.errorMessage = error.response?.data?.error || '注册失败，请稍后重试。';
                this.successMessage = '';
            }
        }
    }
};
</script>

<style scoped>
.register-container {
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #f9f9f9;
}

.form-group {
    margin-bottom: 15px;
}

label {
    display: block;
    margin-bottom: 5px;
}

input {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

button {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 3px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

.error-message {
    color: red;
    margin-top: 10px;
}

.success-message {
    color: green;
    margin-top: 10px;
}
</style>