<template>
  <div class="dashboard">
      <!-- 退出按钮 -->
      <div class="logout-button-container">
          <button class="logout-button" @click="goToHome">退出</button>
      </div>

      <!-- 欢迎信息 -->
      <div class="welcome-section">
          <h1 class="welcome-title">欢迎使用南职大志愿者管理系统</h1>
          <p class="welcome-subtitle">这里是学校志愿者活动的管理平台，您可以在这里查看志愿者信息、管理活动等。</p>
      </div>

      <!-- 主要功能入口 -->
      <div class="features">
          <div class="feature-card" @click="goToVolunteers">
              <div class="feature-icon">
                  <i class="fas fa-users"></i> <!-- Font Awesome 图标 -->
              </div>
              <h2 class="feature-title">志愿者管理</h2>
              <p class="feature-description">查看和管理志愿者信息。</p>
          </div>
          <div class="feature-card" @click="goToEvents">
              <div class="feature-icon">
                  <i class="fas fa-calendar-alt"></i> <!-- Font Awesome 图标 -->
              </div>
              <h2 class="feature-title">活动管理</h2>
              <p class="feature-description">发布和管理志愿者活动。</p>
          </div>
          <div class="feature-card" >
              <div class="feature-icon">
                  <i class="fas fa-chart-bar"></i> <!-- Font Awesome 图标 -->
              </div>
              <h2 class="feature-title">数据统计</h2>
              <p class="feature-description">以下是志愿者活动的统计数据。</p>
          </div>
      </div>

      <!-- 统计数据 -->
      <div class="statistics">
          <div class="statistic-card" @click="goToStatistics">
              <h3 class="statistic-title">志愿者总数</h3>
              <p class="statistic-value">{{ volunteerCount }}</p>
          </div>
          <div class="statistic-card" @click="goToStatistics">
              <h3 class="statistic-title">活动总数</h3>
              <p class="statistic-value">{{ activityCount }}</p>
          </div>
          <div class="statistic-card" @click="goToStatistics">
              <h3 class="statistic-title">总服务时长</h3>
              <p class="statistic-value">{{ totalServiceHours }} 小时+</p>
          </div>
      </div>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import axios from 'axios';
import { ElMessage } from 'element-plus';

export default {
  setup() {
      const router = useRouter();
      const volunteerCount = ref(0);
      const activityCount = ref(0);
      const totalServiceHours = ref(0);

      // 获取志愿者总数
      const fetchVolunteerCount = async () => {
          try {
              const response = await axios.get('http://localhost:3000/api/volunteers/count');
              volunteerCount.value = response.data.count;
          } catch (error) {
              console.error('获取志愿者总数失败:', error);
          }
      };

      // 获取活动总数
      const fetchActivityCount = async () => {
          try {
              const response = await axios.get('http://localhost:3000/api/activities/count');
              activityCount.value = response.data.count;
          } catch (error) {
              console.error('获取活动总数失败:', error);
          }
      };

      // 获取总服务时长
      const fetchTotalServiceHours = async () => {
          try {
              const response = await axios.get('http://localhost:3000/api/participations/total-hours');
              totalServiceHours.value = response.data.totalHours;
          } catch (error) {
              console.error('获取总服务时长失败:', error);
          }
      };

      // 页面加载时获取数据
      onMounted(() => {
          fetchVolunteerCount();
          fetchActivityCount();
          fetchTotalServiceHours();
          ElMessage({
                  message: '欢迎您，管理员',
                  type: 'success',
                  duration: 2000 // 显示2秒
              });
      });

      // 跳转到志愿者管理页面
      const goToVolunteers = () => {
          router.push('/volunteers');
      };

      // 跳转到活动管理页面
      const goToEvents = () => {
          router.push('/events');
      };

      // 跳转到 HOME 页面
      const goToHome = () => {
          // 使用 router.replace 替换当前历史记录
          router.replace('/'); 
      };

      // 跳转到统计页面（可根据实际情况修改）
      const goToStatistics = () => {
          // 这里可以添加跳转到统计页面的逻辑
      };

      return {
          volunteerCount,
          activityCount,
          totalServiceHours,
          goToVolunteers,
          goToEvents,
          goToHome,
          goToStatistics
      };
  },
};
</script>

<style scoped>
.dashboard {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

/* 退出按钮样式 */
.logout-button-container {
  text-align: right;
  margin-bottom: 20px;
}

.logout-button {
  padding: 10px 20px;
  background-color: #dc3545;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.logout-button:hover {
  background-color: #c82333;
}

/* 欢迎信息 */
.welcome-section {
  text-align: center;
  margin-bottom: 40px;
}

.welcome-title {
  font-size: 2.5rem;
  color: #2c3e50;
  margin-bottom: 10px;
}

.welcome-subtitle {
  font-size: 1.2rem;
  color: #666;
}

/* 功能模块 */
.features {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 20px;
  margin-bottom: 40px;
}

.feature-card {
  padding: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  text-align: center;
}

.feature-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.feature-icon {
  font-size: 2.5rem;
  color: #007bff;
  margin-bottom: 15px;
}

.feature-title {
  font-size: 1.5rem;
  color: #333;
  margin-bottom: 10px;
}

.feature-description {
  font-size: 1rem;
  color: #666;
}

/* 统计数据 */
.statistics {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); /* 和 features 保持一致 */
  gap: 20px;
}

.statistic-card {
  padding: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  cursor: pointer; /* 添加鼠标指针样式 */
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  text-align: center;
}

.statistic-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.statistic-title {
  font-size: 1.5rem; /* 和 feature-title 保持一致 */
  color: #333;
  margin-bottom: 10px;
}

.statistic-value {
  font-size: 1.5rem;
  color: #007bff;
  font-weight: bold;
}
</style>