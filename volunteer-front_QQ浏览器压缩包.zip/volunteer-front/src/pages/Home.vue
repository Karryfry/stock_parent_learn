<template>
  <div class="dashboard">
    <!-- 登录注册链接 -->
    <div class="navigation">
      <h2>快速导航</h2>
      <router-link to="/register" class="nav-link">注册</router-link>
      <router-link to="/login" class="nav-link">登录</router-link>
    </div>
    <!-- 欢迎信息 -->
    <div class="welcome-section">
      <h1 class="welcome-title">欢迎使用南职大志愿者管理系统</h1>
      <p class="welcome-subtitle">这里是学校志愿者活动的管理平台，您可以在这里查看志愿者信息、管理活动等。</p>
    </div>
    <!-- 主要功能入口 -->
    <div class="features">
      <div class="feature-card" v-if="isLoggedIn" @click="goToVolunteerInfo">
        <div class="feature-icon">
          <i class="fas fa-users"></i>
        </div>
        <h2 class="feature-title">志愿者信息查看</h2>
        <p class="feature-description">查看个人及其他志愿者信息。</p>
      </div>
      <div class="feature-card" v-if="isLoggedIn" @click="goToEventManagement">
        <div class="feature-icon">
          <i class="fas fa-calendar-alt"></i>
        </div>
        <h2 class="feature-title">活动相关操作</h2>
        <p class="feature-description">查看活动详情、报名及签到等。</p>
      </div>
      <div class="feature-card" v-if="isLoggedIn" @click="goToDataStatistics">
        <div class="feature-icon">
          <i class="fas fa-chart-bar"></i>
        </div>
        <h2 class="feature-title">数据统计查看</h2>
        <p class="feature-description">查看各类志愿者活动统计数据。</p>
      </div>
    </div>
    <!-- 统计数据 -->
    <div class="statistics">
      <div class="statistic-card" v-if="isLoggedIn" @click="goToDataStatistics">
        <h3 class="statistic-title">志愿者总数</h3>
        <p class="statistic-value">{{ volunteerCount }}</p>
      </div>
      <div class="statistic-card" v-if="isLoggedIn" @click="goToDataStatistics">
        <h3 class="statistic-title">活动总数</h3>
        <p class="statistic-value">{{ activityCount }}</p>
      </div>
      <div class="statistic-card" v-if="isLoggedIn" @click="goToDataStatistics">
        <h3 class="statistic-title">总服务时长</h3>
        <p class="statistic-value">{{ totalServiceHours }} 小时+</p>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import axios from 'axios';
import { ElMessage } from 'element-plus';

export default {
  setup() {
    const router = useRouter();
    const volunteerCount = ref(0);
    const activityCount = ref(0);
    const totalServiceHours = ref(0);
    const isLoggedIn = ref(false);

    const fetchVolunteerCount = async () => {
      try {
        const response = await axios.get('http://localhost:3000/api/volunteers/count');
        volunteerCount.value = response.data.count;
      } catch (error) {
        console.error('获取志愿者总数失败:', error);
      }
    };

    const fetchActivityCount = async () => {
      try {
        const response = await axios.get('http://localhost:3000/api/activities/count');
        activityCount.value = response.data.count;
      } catch (error) {
        console.error('获取活动总数失败:', error);
      }
    };

    const fetchTotalServiceHours = async () => {
      try {
        const response = await axios.get('http://localhost:3000/api/participations/total-hours');
        totalServiceHours.value = response.data.totalHours;
      } catch (error) {
        console.error('获取总服务时长失败:', error);
      }
    };

    onMounted(() => {
      fetchVolunteerCount();
      fetchActivityCount();
      fetchTotalServiceHours();
      const loggedIn = localStorage.getItem('isLoggedIn');
      if (loggedIn === 'true') {
        isLoggedIn.value = true;
      }
    });

    const goToVolunteerInfo = () => {
      router.push('/volunteerInfo');
    };

    const goToEventManagement = () => {
      router.push('/eventManagement');
    };

    const goToDataStatistics = () => {
      router.push('/dataStatistics');
    };

    return {
      volunteerCount,
      activityCount,
      totalServiceHours,
      isLoggedIn,
      goToVolunteerInfo,
      goToEventManagement,
      goToDataStatistics
    };
  }
};
</script>

<style scoped>
.dashboard {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.navigation {
  text-align: right;
  margin-bottom: 20px;
}

.navigation h2 {
  font-size: 2rem;
  color: #2c3e50;
  margin-bottom: 15px;
}

.nav-link {
  display: inline-block;
  margin: 10px;
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  text-decoration: none;
  border-radius: 5px;
  font-size: 1.1rem;
  transition: background-color 0.3s ease;
}

.nav-link:hover {
  background-color: #0056b3;
}

.welcome-section {
  text-align: center;
  margin-bottom: 40px;
}

.welcome-title {
  font-size: 2.5rem;
  color: #2c3e50;
  margin-bottom: 10px;
}

.welcome-subtitle {
  font-size: 1.2rem;
  color: #666;
}

.features {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 20px;
  margin-bottom: 40px;
}

.feature-card {
  padding: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  text-align: center;
}

.feature-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.feature-icon {
  font-size: 2.5rem;
  color: #007bff;
  margin-bottom: 15px;
}

.feature-title {
  font-size: 1.5rem;
  color: #333;
  margin-bottom: 10px;
}

.feature-description {
  font-size: 1rem;
  color: #666;
}

.statistics {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 20px;
}

.statistic-card {
  padding: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  text-align: center;
}

.statistic-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.statistic-title {
  font-size: 1.5rem;
  color: #333;
  margin-bottom: 10px;
}

.statistic-value {
  font-size: 1.5rem;
  color: #007bff;
  font-weight: bold;
}
</style>