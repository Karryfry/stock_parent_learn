<template>
    <div class="personal-center-container">
        <h1>个人中心</h1>
        <h2>完善志愿者信息</h2>
        <form @submit.prevent="handleUpdateVolunteer">
            <div class="form-group">
                <label for="name">姓名:</label>
                <input id="name" v-model="volunteerInfo.name" type="text" placeholder="请输入姓名" required />
            </div>
            <div class="form-group">
                <label for="studentId">学号:</label>
                <input id="studentId" v-model="volunteerInfo.studentId" type="text" placeholder="请输入学号" required />
            </div>
            <div class="form-group">
                <label for="phone">联系方式:</label>
                <input id="phone" v-model="volunteerInfo.phone" type="text" placeholder="请输入联系方式" required />
            </div>
            <div class="form-group">
                <label for="gender">性别:</label>
                <select id="gender" v-model="volunteerInfo.gender" required>
                    <option value="男">男</option>
                    <option value="女">女</option>
                </select>
            </div>
            <div class="form-group">
                <label for="age">年龄:</label>
                <input id="age" v-model="volunteerInfo.age" type="number" placeholder="请输入年龄" />
            </div>
            <div class="form-group">
                <label for="email">邮箱:</label>
                <input id="email" v-model="volunteerInfo.email" type="email" placeholder="请输入邮箱" />
            </div>
            <div class="form-group">
                <label for="address">地址:</label>
                <input id="address" v-model="volunteerInfo.address" type="text" placeholder="请输入地址" />
            </div>
            <button type="submit">保存</button>
        </form>
        <div v-if="errorMessage" class="error-message">{{ errorMessage }}</div>
        <div v-if="successMessage" class="success-message">{{ successMessage }}</div>
    </div>
</template>

<script>
import axios from 'axios';
import { useRouter } from 'vue-router';
import { useAuthStore } from '../stores/auth'; // 根据实际路径调整

export default {
    data() {
        return {
            volunteerInfo: {
                name: '',
                studentId: '',
                phone: '',
                gender: '男',
                age: null,
                email: '',
                address: ''
            },
            errorMessage: '',
            successMessage: ''
        };
    },
    setup() {
        const router = useRouter();
        const authStore = useAuthStore();

        return {
            router,
            authStore
        };
    },
    async created() {
        const userId = this.authStore.user?.id;
        if (!userId) {
            this.router.push('/login');
        } else {
            try {
                const response = await axios.get(`http://localhost:3000/api/getVolunteerInfo/${userId}`);
                this.volunteerInfo = {
                    name: response.data.name || '',
                    studentId: response.data.student_id || '',
                    phone: response.data.phone || '',
                    gender: response.data.gender || '男',
                    age: response.data.age || null,
                    email: response.data.email || '',
                    address: response.data.address || ''
                };
            } catch (error) {
                console.error('获取志愿者信息失败:', error);
                this.errorMessage = error.response?.data?.error || '获取志愿者信息失败，请稍后重试';
            }
        }
    },
    methods: {
        async handleUpdateVolunteer() {
            try {
                const userId = this.authStore.user?.id;
                const response = await axios.post('http://localhost:3000/api/addVolunteerInfo', {
                    userId,
                   ...this.volunteerInfo
                });
                this.successMessage = '志愿者信息完善成功！';
                this.errorMessage = '';
            } catch (error) {
                this.errorMessage = error.response?.data?.error || '信息完善失败，请稍后重试。';
                this.successMessage = '';
            }
        }
    }
};
</script>

<style scoped>
.personal-center-container {
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #f9f9f9;
}

.form-group {
    margin-bottom: 15px;
}

label {
    display: block;
    margin-bottom: 5px;
}

input,
select {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

button {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 3px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

.error-message {
    color: red;
    margin-top: 10px;
}

.success-message {
    color: green;
    margin-top: 10px;
}
</style>