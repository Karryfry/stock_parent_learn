import { createRouter, createWebHistory } from 'vue-router';
import Home from './pages/Home.vue';
import Volunteers from './pages/Volunteers.vue';
import Events from './pages/Events.vue';
import Login from './pages/Login.vue';
import Dashboard from './pages/Dashboard.vue';
import Register from './pages/Register.vue';
import PersonalCenter from './pages/PersonalCenter.vue';
import { useAuthStore } from './stores/auth'; // 导入 useAuthStore

const routes = [
  { path: '/', component: Home },
  { path: '/volunteers', component: Volunteers },
  { path: '/events', component: Events },
  { path: '/login', component: Login },
  { path: '/dashboard', component:Dashboard },
  { path: '/register', component:Register },
  { path: '/personal', component:PersonalCenter },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});
router.beforeEach((to, from, next) => {
  const authStore = useAuthStore();
  if (to.meta.requiresAuth && !authStore.isAuthenticated) {
    next('/login'); // 如果未登录，跳转到登录页面
  } else {
    next();
  }
});
export default router;