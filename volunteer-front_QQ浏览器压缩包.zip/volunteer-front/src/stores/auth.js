import { defineStore } from 'pinia';
import { loginApi } from '../services/api'; // 确保导入路径正确

export const useAuthStore = defineStore('auth', {
  state: () => ({
    user: null,
    isAuthenticated: false
  }),
  actions: {
    async login(username, password) {
      try {
        const response = await loginApi(username, password); // 调用登录 API
        this.user = response.user;
        this.isAuthenticated = true;
        return this.user; // 返回包含用户信息（含 role）的对象
      } catch (error) {
        throw new Error('登录失败');
      }
    },
    logout() {
      this.user = null;
      this.isAuthenticated = false;
    }
  },
  getters: {
    getUserRole: (state) => {
      return state.user? state.user.role : null;
    }
  }
});