import axios from 'axios';

const API_URL = 'http://localhost:3000/api'; // 后端 API 地址

// 登录接口
export const loginApi = async (username, password) => {
    try {
        const response = await axios.post(`${API_URL}/login`, {
            username,
            password
        });

        // 检查响应状态码
        if (response.status === 200) {
            return response.data;
        } else {
            // 若状态码不是 200，抛出包含状态码和消息的错误
            throw new Error(`登录失败，状态码: ${response.status}，消息: ${response.data.message}`);
        }
    } catch (error) {
        if (axios.isAxiosError(error)) {
            // 处理 Axios 错误，例如网络错误或服务器返回错误状态码
            if (error.response) {
                // 服务器返回了错误响应
                throw new Error(`登录失败，状态码: ${error.response.status}，消息: ${error.response.data.message}`);
            } else if (error.request) {
                // 请求已发送，但没有收到响应
                throw new Error('登录失败，未收到服务器响应，请检查网络连接');
            } else {
                // 设置请求时出错
                throw new Error(`登录失败，请求设置出错: ${error.message}`);
            }
        } else {
            // 处理非 Axios 错误
            throw new Error(`登录失败，发生未知错误: ${error.message}`);
        }
    }
};


// 获取志愿者列表
export const getVolunteers = async () => {
  try {
    const response = await axios.get(`${API_URL}/volunteers`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// 添加新志愿者
export const addVolunteer = async (volunteer) => {
  try {
    const response = await axios.post(`${API_URL}/volunteers`, volunteer);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// 更新志愿者信息
export const updateVolunteer = async (id, volunteer) => {
  try {
    const response = await axios.put(`${API_URL}/volunteers/${id}`, volunteer);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// 删除志愿者
export const deleteVolunteer = async (id) => {
  try {
    const response = await axios.delete(`${API_URL}/volunteers/${id}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};
//获取活动列表
export const getEvents = async () => {
  try {
    const response = await axios.get(`${API_URL}/activities`);
    return response.data;
  } catch (error) {
    throw error;
  }
};
// 新增活动
export const createEvent = async (eventData) => {
  try {
    const response = await axios.post(`${API_URL}/activities`, eventData);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// 编辑活动
export const updateEvent = async (eventId, eventData) => {
  try {
    const response = await axios.put(`${API_URL}/activities/${eventId}`, eventData);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// 删除活动
export const deleteEvent = async (eventId) => {
  try {
    const response = await axios.delete(`${API_URL}/activities/${eventId}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export default {
  loginApi,
  getVolunteers,
  addVolunteer,
  updateVolunteer,
  deleteVolunteer,
  getEvents,
  createEvent,
  updateEvent,
  deleteEvent
};