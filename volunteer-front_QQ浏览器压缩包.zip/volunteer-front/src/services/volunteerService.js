import axios from 'axios';

const API_URL = 'http://localhost:3000/api'; // 后端 API 地址

export default {
  async getVolunteers() {
    const response = await axios.get(`${API_URL}/volunteers`);
    return response.data;
  },
  async addVolunteer(volunteer) {
    const response = await axios.post(`${API_URL}/volunteers`, volunteer);
    return response.data;
  },
  async deleteVolunteer(id) {
    const response = await axios.delete(`${API_URL}/volunteers/${id}`);
    return response.data;
  },
};