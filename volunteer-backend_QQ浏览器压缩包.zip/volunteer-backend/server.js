const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mysql = require('mysql2/promise');

const app = express();

// 创建 MySQL 连接池
const pool = mysql.createPool({
  host: 'localhost', // 数据库地址
  user: 'root', // 数据库用户名
  password: '191666', // 数据库密码
  database: 'volunteer_management', // 数据库名称
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// 测试数据库连接
pool.getConnection((err, connection) => {
  if (err) {
    console.error('数据库连接失败:', err);
  } else {
    console.log('数据库连接成功');
    connection.release();
  }
});
// // 中间件，为所有响应设置禁用缓存的头信息
// app.use((req, res, next) => {
//   res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
//   res.setHeader('Pragma', 'no-cache');
//   res.setHeader('Expires', '0');
//   next();
// });
// app.get('*', (req, res) => {
//   // 返回页面内容，这里假设是渲染 Vue 应用的入口文件 index.html
//   res.sendFile(__dirname + '"D:\volunteer-front\index.html"'); 
// });


// 使用中间件
app.use(bodyParser.json()); // 解析 JSON 请求体
app.use(cors()); // 允许跨域请求


// 模拟用户数据（实际项目中应从数据库获取）
// const users = [
//   { id: 1, username: 'admin', password: '123456' },
//   { id: 2, username: 'user', password: 'password' },
// ];
// 志愿者总数接口
app.get('/api/volunteers/count', async (req, res) => {
  try {
      const query = 'SELECT COUNT(*) AS count FROM volunteers';
      // 执行查询
      const [results] = await pool.execute(query);
      // 提取查询结果中的 count 值
      const count = results[0].count;
      // 返回成功响应
      res.json({ success: true, count });
  } catch (error) {
      // 记录错误日志
      console.error('获取志愿者数量时出现数据库错误:', error);
      // 返回错误响应
      res.status(500).json({ success: false, message: '数据库错误，请稍后重试' });
  }
});
// 活动总数接口
app.get('/api/activities/count', async (req, res) => {
  try {
      const query = 'SELECT COUNT(*) AS count FROM activities';
      const [results] = await pool.execute(query);
      const count = results[0].count;
      res.json({ success: true, count });
  } catch (error) {
      console.error('获取活动总数时出现数据库错误:', error);
      res.status(500).json({ success: false, message: '数据库错误，请稍后重试' });
  }
});

// 服务总时长接口
app.get('/api/participations/total-hours', async (req, res) => {
  try {
      const query = 'SELECT SUM(service_hours) AS totalHours FROM participations';
      const [results] = await pool.execute(query);
      const totalHours = results[0].totalHours || 0;
      res.json({ success: true, totalHours });
  } catch (error) {
      console.error('获取总服务时长时出现数据库错误:', error);
      res.status(500).json({ success: false, message: '数据库错误，请稍后重试' });
  }
});
// 用户注册接口
app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;
  try {
    const [existingUser] = await pool.execute('SELECT * FROM users WHERE username =?', [username]);
    if (existingUser.length > 0) {
      return res.status(400).json({ error: '该用户名已存在，请使用其他用户名' });
    }

    const [userResult] = await pool.execute(
      'INSERT INTO users (username, password) VALUES (?,?)',
      [username, password]
    );
    const newUserId = userResult.insertId;

    res.status(201).json({ id: newUserId, username });
  } catch (error) {
    console.error('用户注册失败:', error);
    res.status(500).json({ error: '用户注册失败' });
  }
});
// 根据用户 ID 获取志愿者信息
app.get('/api/getVolunteerInfo/:userId', async (req, res) => {
  const userId = req.params.userId;
  try {
      const [rows] = await pool.execute('SELECT * FROM volunteers WHERE user_id =?', [userId]);
      if (rows.length > 0) {
          res.json(rows[0]);
      } else {
          res.status(404).json({ error: '未找到该用户的志愿者信息' });
      }
  } catch (error) {
      console.error('获取志愿者信息失败:', error);
      res.status(500).json({ error: '获取志愿者信息失败，请稍后重试' });
  }
});

// 完善志愿者信息接口
app.post('/api/addVolunteerInfo', async (req, res) => {
  const { userId, name, student_id, phone, gender, age, email, address } = req.body;
  try {
      const [existingVolunteer] = await pool.execute('SELECT * FROM volunteers WHERE student_id =?', [student_id]);
      if (existingVolunteer.length > 0) {
          return res.status(400).json({ error: '该学号已存在，请使用其他学号' });
      }

      const [volunteerResult] = await pool.execute(
          'INSERT INTO volunteers (user_id, name, student_id, phone, gender, age, email, address) VALUES (?,?,?,?,?,?,?,?)',
          [userId, name, student_id, phone, gender, age, email, address]
      );
      const newVolunteerId = volunteerResult.insertId;

      const [newVolunteer] = await pool.execute('SELECT * FROM volunteers WHERE id =?', [newVolunteerId]);
      res.status(201).json(newVolunteer[0]);
  } catch (error) {
      console.error('完善志愿者信息失败:', error);
      res.status(500).json({ error: '完善志愿者信息失败，请稍后重试' });
  }
});


// 登录接口
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  try {
      // 执行数据库查询
      const results = await pool.query('SELECT * FROM users WHERE username = ? AND password = ?', [username, password]);
      // 确保 results 是数组且有元素
      if (Array.isArray(results) && results.length > 0) {
          const rows = results[0]; // 获取查询结果
          if (Array.isArray(rows) && rows.length > 0) {
              // 登录成功
              const user = rows[0];
              res.status(200).json({ user });
          } else {
              // 登录失败
              res.status(401).json({ message: '用户名或密码错误' });
          }
      } else {
          // 处理异常情况
          res.status(500).json({ message: '数据库查询结果异常' });
      }
  } catch (error) {
      console.error('数据库查询出错:', error);
      res.status(500).json({ message: '服务器内部错误，请稍后再试' });
  }
});

// 获取志愿者列表
app.get('/api/volunteers', async (req, res) => {
  try {
      const [rows] = await pool.execute('SELECT * FROM volunteers');
      res.json(rows);
  } catch (error) {
      console.error('获取志愿者列表失败:', error);
      res.status(500).json({ error: '获取志愿者列表失败' });
  }
});

// // 添加新志愿者
// app.post('/api/volunteers', async (req, res) => {
//   const { name, student_id, phone, gender, age, email, address, username, password } = req.body;
//   const connection = await pool.getConnection();
//   try {
//       await connection.beginTransaction();

//       // 检查学号是否已存在
//       const [existingVolunteer] = await connection.execute('SELECT * FROM volunteers WHERE student_id =?', [student_id]);
//       if (existingVolunteer.length > 0) {
//           await connection.rollback();
//           return res.status(400).json({ error: '该学号已存在，请使用其他学号' });
//       }

//       // 创建用户记录
//       const [userResult] = await connection.execute(
//           'INSERT INTO users (username, password) VALUES (?,?)',
//           [username, password]
//       );
//       const newUserId = userResult.insertId;

//       // 创建志愿者记录
//       const [volunteerResult] = await connection.execute(
//           'INSERT INTO volunteers (user_id, name, student_id, phone, gender, age, email, address) VALUES (?,?,?,?,?,?,?,?)',
//           [newUserId, name, student_id, phone, gender, age, email, address]
//       );
//       const newVolunteerId = volunteerResult.insertId;

//       await connection.commit();

//       const [newVolunteer] = await connection.execute('SELECT * FROM volunteers WHERE id =?', [newVolunteerId]);
//       res.status(201).json(newVolunteer[0]);
//   } catch (error) {
//       await connection.rollback();
//       console.error('添加志愿者失败:', error);
//       res.status(500).json({ error: '添加志愿者失败' });
//   } finally {
//       connection.release();
//   }
// });

// 更新志愿者信息
app.put('/api/volunteers/:id', async (req, res) => {
  const volunteerId = req.params.id;
  const { user_id, name, student_id, phone, gender, age, email, address } = req.body;
  try {
      await pool.execute(
          'UPDATE volunteers SET user_id =?, name =?, student_id =?, phone =?, gender =?, age =?, email =?, address =? WHERE id =?',
          [user_id, name, student_id, phone, gender, age, email, address, volunteerId]
      );
      const [updatedVolunteer] = await pool.execute('SELECT * FROM volunteers WHERE id =?', [volunteerId]);
      res.json(updatedVolunteer[0]);
  } catch (error) {
      console.error('更新志愿者信息失败:', error);
      res.status(500).json({ error: '更新志愿者信息失败' });
  }
});

// 删除志愿者
app.delete('/api/volunteers/:id', async (req, res) => {
  const volunteerId = req.params.id;
  try {
      await pool.execute('DELETE FROM volunteers WHERE id =?', [volunteerId]);
      res.json({ message: '志愿者删除成功' });
  } catch (error) {
      console.error('删除志愿者失败:', error);
      res.status(500).json({ error: '删除志愿者失败' });
  }
});
// 获取活动列表
app.get('/api/activities', async (req, res) => {
  try {
      const [rows] = await pool.execute('SELECT * FROM activities');
      res.json(rows);
  } catch (error) {
      console.error('获取活动列表失败:', error);
      res.status(500).json({ error: '获取活动列表失败' });
  }
});
// 新增活动
app.post('/api/activities', async (req, res) => {
  const { title, start_time, end_time, location, description, organizer } = req.body;
  try {
      const [result] = await pool.execute(
          'INSERT INTO activities (title, start_time, end_time, location, description, organizer) VALUES (?,?,?,?,?,?)',
          [title, start_time, end_time, location, description, organizer]
      );
      const newActivityId = result.insertId;
      const [newActivity] = await pool.execute('SELECT * FROM activities WHERE id =?', [newActivityId]);
      res.status(201).json(newActivity[0]);
  } catch (error) {
      console.error('新增活动失败:', error);
      res.status(500).json({ error: '新增活动失败' });
  }
});

// 编辑活动
app.put('/api/activities/:id', async (req, res) => {
  const activityId = req.params.id;
  const { title, start_time, end_time, location, description, organizer } = req.body;
  try {
      await pool.execute(
          'UPDATE activities SET title =?, start_time =?, end_time =?, location =?, description =?, organizer =? WHERE id =?',
          [title, start_time, end_time, location, description, organizer, activityId]
      );
      const [updatedActivity] = await pool.execute('SELECT * FROM activities WHERE id =?', [activityId]);
      res.json(updatedActivity[0]);
  } catch (error) {
      console.error('编辑活动失败:', error);
      res.status(500).json({ error: '编辑活动失败' });
  }
});

// 删除活动
app.delete('/api/activities/:id', async (req, res) => {
  const activityId = req.params.id;
  try {
      await pool.execute('DELETE FROM activities WHERE id =?', [activityId]);
      res.json({ message: '活动删除成功' });
  } catch (error) {
      console.error('删除活动失败:', error);
      res.status(500).json({ error: '删除活动失败' });
  }
});


// 启动服务器
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`服务器运行在 http://localhost:${PORT}`);
});